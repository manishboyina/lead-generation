import sys, os

# Adds the root folder to the python path
sys.path.insert(1, os.path.join(sys.path[0], '..'))